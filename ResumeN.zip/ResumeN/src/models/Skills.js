
class Skills{
    constructor(id,name="not-set",rating=0){
        this.id = id;
        this.name=name;
        this.rating = rating;
    }
}
export default Skills;