
class Education {
    constructor(id, school="not-set", degree="not-set", started="not-set", finished="not-set", description="not-set") {
        this.id = id;
        this.school = school;
        this.degree = degree;
        this.started = started;
        this.finished = finished;
        this.description = description;
    }
}
export default Education;