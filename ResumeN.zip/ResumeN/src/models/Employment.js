
class Employment{
     
    constructor(id,jobTitle="not-set",employer="not-set",begin="not-set",end="not-set",description="not-set"){
        this.id = id;
        this.jobTitle = jobTitle;
        this.employer = employer;
        this.begin = begin;
        this.end = end;
        this.description = description;
    }
}
export default Employment;