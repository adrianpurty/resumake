
class Language{
    constructor(id,name="not-set",level="not-set"){
        this.id = id;
        this.name=name;
        this.level = level;
    }
}
export default Language;